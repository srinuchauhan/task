import { Component, OnInit} from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Component({
   selector: 'app-mainpage',
   templateUrl: './mainpage.component.html',
   styleUrls: ['./mainpage.component.css']
})

export class MainpageComponent implements OnInit {
   
   data:any;
   constructor(private http: HttpClient) {
   
      }
   
   ngOnInit() {
   this.getUserDeatails();
   }
   
   
   getUserDeatails(){
   return this.http.get( "https://reqres.in/api/users?page=1").subscribe(resp => {
   console.log(resp);
   alert(resp);
   this.data=resp;
   
   });
}


   }