import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

import { RouterModule, Routes} from '@angular/router';
import { FormsModule} from '@angular/forms';

import {HttpModule} from "@angular/http";
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';

import { LoginComponent } from './login/login.component';
import { MainpageComponent } from './mainpage/mainpage.component';

const appRoutes: Routes = [
  
 
   {
      path:'',
      component:LoginComponent
   },

   {
      path: 'app-mainpage',
      component: MainpageComponent
   }
];

@NgModule({
   declarations: [
      AppComponent,
      LoginComponent,
      MainpageComponent,
   ],
   
   imports: [
      BrowserModule,
      ReactiveFormsModule,
      RouterModule.forRoot(appRoutes),
      HttpModule,
      HttpClientModule,
   ],
   providers: [],
   bootstrap: [AppComponent]
})
export class AppModule { }
